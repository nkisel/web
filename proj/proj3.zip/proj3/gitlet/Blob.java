package gitlet;

import java.io.File;
import java.io.Serializable;

import static gitlet.Utils.readContents;
import static gitlet.Utils.sha1;

/** A Blob is an Object representation of a file, consisting
 *  the file's name, contents, and a unique hash code generated
 *  from each of these fields.
 *
 *  @author Nick Kisel */
public class Blob implements Serializable, Comparable {

    /** Constructs a Blob from the file at PATH. */
    Blob(File path) {
        _file = path;
        _name = path.getName();
        _content = readContents(path);
        _id = sha1(_name, _content);
    }

    /** Return this Blob's unique SHA-1 hash. */
    public String id() {
        return _id;
    }

    /** Return this file's name. */
    public String name() {
        return _name;
    }

    /** Return this file's contents. */
    public byte[] content() {
        return _content;
    }

    @Override
    public int compareTo(Object o) {
        return name().compareTo(((Blob) o).name());
    }

    @Override
    public boolean equals(Object obj) {
        return id().equals(((Blob) obj).id());
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    /** The (almost) unique SHA-1 hash value for this blob. */
    private String _id;

    /** Filename. */
    private String _name;

    /** File contents. */
    private byte[] _content;

    /** The file referred to by this blob. */
    private transient File _file;

}
