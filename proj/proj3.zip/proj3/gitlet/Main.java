package gitlet;

import java.io.File;
import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.TreeMap;
import static gitlet.Utils.*;

/** Driver class for Gitlet, the tiny stupid version-control system.
 *  @author Nick Kisel
 */
public class Main implements Serializable {

    /** Usage: java gitlet.Main ARGS, where ARGS contains
     *  <COMMAND> <OPERAND> .... */
    public static void main(String... args) {
        try {
            new Main(args).storeGitlet();
            return;
        } catch (GitletException excp) {
            System.err.printf("Error: %s%n", excp.getMessage());
        }

    }

    /** Process the arguments ARGS passed in by command line. */
    Main(String[] args) {
        if (args.length == 0) {
            System.out.println(NO_ARGS);
            System.exit(0);
        }

        if (!isin(COMMANDS, args[0])) {
            message("No command with that name exists.");
            System.exit(0);
        } else {
            _command = args[0];
        }

        if (!getGitlet()) {
            if (_command.equals("init")) {
                expectedArgs(1, args);
                init();
            } else {
                System.out.println("Not in an initialized Gitlet directory.");
                System.exit(0);
            }
        } else {
            readGitlet();
            commandSwitch(args);
        }
    }

    /** Determine the command to execute from ARGS. */
    private void commandSwitch(String[] args) {
        switch (_command) {
        case "init":
            message("A Gitlet version-control system "
                    + "already exists in the current directory.");
            System.exit(0);
            break;
        case "add":
            expectedArgs(2, args);
            add(args[1]);
            break;
        case "commit":
            expectedArgs(2, args);
            commit(args[1]);
            break;
        case "rm":
            expectedArgs(2, args);
            rm(args[1]);
            break;
        case "log":
            expectedArgs(1, args);
            log();
            break;
        case "global-log":
            expectedArgs(1, args);
            globalLog();
            break;
        case "find":
            expectedArgs(2, args);
            find(args[1]);
            break;
        case "status":
            expectedArgs(1, args);
            status();
            break;
        case "checkout":
            switch (args.length) {
            case 2:
                checkoutBranch(args[1]);
                break;
            case 3:
                checkoutFile(args[2]);
                break;
            case 4:
                checkoutFile(args[1], args[3]);
                break;
            default:
                expectedArgs(-1, args);
                break;
            }
            break;
        default:
            commandSwitchExtension(args);
        }
    }

    /** Determine the command to execute from ARGS. */
    private void commandSwitchExtension(String[] args) {
        switch (_command) {
        case "branch":
            expectedArgs(2, args);
            branch(args[1]);
            break;
        case "rm-branch":
            expectedArgs(2, args);
            removeBranch(args[1]);
            break;
        case "reset":
            expectedArgs(2, args);
            reset(args[1]);
            break;
        case "merge":
            expectedArgs(2, args);
            merge(args[1], false);
            break;
        case "add-remote":
            expectedArgs(3, args);
            addRemote(args[1], args[2]);
            break;
        case "rm-remote":
            expectedArgs(2, args);
            rmRemote(args[1]);
            break;
        case "push":
            expectedArgs(3, args);
            push(args[1], args[2]);
            break;
        case "fetch":
            expectedArgs(3, args);
            fetch(args[1], args[2]);
            break;
        case "pull":
            expectedArgs(3, args);
            pull(args[1], args[2]);
            break;
        default:
            break;
        }
    }

    /** Creates a new Gitlet repository consisting of just the original commit
     *  in the working directory. */
    private void init() {

        _gitletPath = new File(workingDirectory, ".gitlet");
        _filesPath = new File(_gitletPath + "/files");
        _commitsPath = new File(_gitletPath + "/commits");
        _stagingPath = new File(_gitletPath + "/staging");
        _untrackedPath = new File(_gitletPath + "/untracked");
        _remotesPath = new File(_gitletPath + "/remotes");

        _gitletPath.mkdir();
        _filesPath.mkdir();
        _commitsPath.mkdir();
        _stagingPath.mkdir();
        _untrackedPath.mkdir();
        _remotesPath.mkdir();

        Commit initial = new Commit();

        writeObject(new File(_commitsPath + File.separator + initial.id()),
                initial);

        _branch = "master";
        _branches = new TreeMap<>();
        _branches.put(_branch, initial.id());

        _stagedFiles = new HashMap<>();
        _remotes = new HashSet<>();

    }

    /** Converts FILENAME to a Blob object and stores it in
     * workingDirectory/.gitlet/staging/ if it does not already exist there. */
    private void add(String fileName) {
        File file = getFile(fileName);


        Blob addToStaging = new Blob(file);
        File stagingLocation = new File(_stagingPath
                + File.separator + addToStaging.id());

        if (head().update().fileEquals(addToStaging)) {
            stagingLocation.delete();
            System.exit(0);
        }

        if (_stagedFiles.containsKey(fileName)) {
            (getFile(_stagingPath
                    + SEPARATOR + _stagedFiles.get(fileName))).delete();
        }

        if (plainFilenamesIn(_untrackedPath).contains(addToStaging.id())) {
            (getFile(_untrackedPath
                    + File.separator + addToStaging.id())).delete();
        }

        Utils.writeObject(stagingLocation, addToStaging);
    }

    /** Creates a new commit with message MESSAGE, consisting of all files
     *  added in the parent commit updated to the versions most recently
     *  passed in to the add command, except for those removed by the
     *  rm command. Clears both the staging and removal directory. */
    private void commit(String message) {
        if (message == null || message.equals("")) {
            message("Please enter a commit message.");
            System.exit(0);
        }

        List<String> untrack = plainFilenamesIn(_untrackedPath);
        List<String> staged = plainFilenamesIn(_stagingPath);

        if (untrack.size() + staged.size() == 0) {
            message("No changes added to the commit.");
            System.exit(0);
        }

        Commit newCommit = new Commit(head(), message, untrack, staged);

        for (String fileID : staged) {
            File untrackedLocation = new File(_untrackedPath + "/" + fileID);
            File stagedLocation = new File(_stagingPath + "/" + fileID);
            File filesLocation = new File(_filesPath + "/" + fileID);
            writeObject(filesLocation, readObject(stagedLocation, Blob.class));
            stagedLocation.delete();
            untrackedLocation.delete();
        }

        for (String fileID : untrack) {
            File untrackedLocation = new File(_untrackedPath + "/" + fileID);
            untrackedLocation.delete();
        }

        writeObject(new File(_commitsPath + "/" + newCommit.id()), newCommit);
        _branches.put(branch(), newCommit.id());
        _stagedFiles.clear();
    }

    /** Create a merge commit with parents PARENT and MERGEPARENT
     *  and message MESSAGE. */
    private void mergeCommit(Commit parent, Commit mergeParent,
                             String message) {
        List<String> untrack = plainFilenamesIn(_untrackedPath);
        List<String> staged = plainFilenamesIn(_stagingPath);

        Commit cmt = new Commit(parent, mergeParent, message, untrack, staged);

        for (String fileID : staged) {
            File untrackedLocation = new File(_untrackedPath + "/" + fileID);
            File stagedLocation = new File(_stagingPath + "/" + fileID);
            File filesLocation = new File(_filesPath + "/" + fileID);
            writeObject(filesLocation, readObject(stagedLocation, Blob.class));
            stagedLocation.delete();
            untrackedLocation.delete();
        }

        for (String fileID : untrack) {
            File untrackedLocation = new File(_untrackedPath + "/" + fileID);
            untrackedLocation.delete();
        }

        writeObject(new File(_commitsPath + "/" + cmt.id()), cmt);
        _branches.put(branch(), cmt.id());
    }

    /** Removes FILENAME from both the working directory and the staging
     *  directory. */
    private void rm(String fileName) {
        File file = getFile(fileName);
        boolean stagedOrTracked = false;

        Blob rmFromStaging = new Blob(file);
        File stagingLocation = new File(_stagingPath
                + "/" + rmFromStaging.id());

        if (stagingLocation.isFile()) {
            stagingLocation.delete();
            _stagedFiles.remove(fileName);
            stagedOrTracked = true;
        }

        if (head().files().containsKey(rmFromStaging.id())) {
            File untrackLocation = new File(_untrackedPath
                    + "/" + rmFromStaging.id());
            Utils.writeObject(untrackLocation, rmFromStaging);
            restrictedDelete(file);
            stagedOrTracked = true;
        }

        if (!stagedOrTracked) {
            message("No reason to remove the file.");
        }
    }

    /** Prints a log of all commits on and behind the head pointer. */
    private void log() {
        Commit commit = head();
        while (commit != null) {
            message("===");
            message("commit %s", commit.id());
            if (commit.isMerge()) {
                message("Merge: "
                        + commit.parent().id().substring(0, 7) + " "
                        + commit.mergeParent().id().substring(0, 7));
            }
            message("Date: %s", commit.time());
            message("%s\n", commit.message());
            commit = commit.parent();
        }
        System.exit(0);
    }

    /** Prints a log of all commits ever made, regardless of branch. */
    private void globalLog() {
        List<String> allCommits = plainFilenamesIn(_commitsPath);
        for (String commitID : allCommits) {
            File commitPath = new File(_commitsPath + "/" + commitID);
            Commit commit = readObject(commitPath, Commit.class);
            message("===");
            message("commit %s", commit.id());
            message("Date: %s", commit.time());
            message("%s\n", commit.message());
        }

        System.exit(0);
    }

    /** Prints a log of commits that have a matching commit MESSAGE. */
    private void find(String message) {
        boolean anyFound = false;
        List<String> allCommits = plainFilenamesIn(_commitsPath);

        for (String commitID : allCommits) {
            File commitPath = new File(_commitsPath + "/" + commitID);
            Commit commit = readObject(commitPath, Commit.class);
            if (commit.message().equals(message)) {
                anyFound = true;
                message("===");
                message("commit %s", commit.id());
                message("Date: %s", commit.time());
                message("%s\n", commit.message());
            }
        }
        if (!anyFound) {
            message("Found no commit with that message.");
        }

        System.exit(0);
    }

    /** Prints a log of commits that have a matching commit message. */
    private void status() {
        message("=== Branches ===");
        for (String branch : _branches.keySet()) {
            if (branch.equals(branch())) {
                message("*" + branch);
            } else {
                message(branch);
            }
        }

        message("\n=== Staged Files ===");
        TreeMap<String, Blob> stagedFiles = getOrderedFilesByName(_stagingPath);
        for (String file : stagedFiles.keySet()) {
            message(stagedFiles.get(file).name());
        }

        message("\n=== Removed Files ===");
        TreeMap<String, Blob> untrackedFiles =
                getOrderedFilesByName(_untrackedPath);
        for (String file : untrackedFiles.keySet()) {
            message(untrackedFiles.get(file).name());
        }

        message("\n=== Modifications Not Staged For Commit ===");
        TreeMap<String, Blob> directoryFiles =
                getOrderedFiles(workingDirectory);
        List<Blob> headFiles = head().update().getFiles();
        for (Blob file : headFiles) {
            if (directoryFiles.containsKey(file.name())) {
                if (!directoryFiles.get(file.name()).equals(file)
                        && (!stagedFiles.containsKey(file.name()))) {
                    message(file.name() + " (modified)");
                }
            } else {
                if (!untrackedFiles.containsKey(file.name())) {
                    message(file.name() + " (removed)");
                }
            }
        }

        for (Blob file : stagedFiles.values()) {
            if (directoryFiles.containsKey(file.name())) {
                if (!directoryFiles.get(file.name()).equals(file)) {
                    message(file.name() + " (modified)");
                }
            } else {
                message(file.name() + " (removed)");
            }
        }

        message("\n=== Untracked Files ===");
        for (String file : directoryFiles.keySet()) {
            if ((!stagedFiles.containsKey(file))
                    && (!untrackedFiles.containsKey(file))
                    && (!head().names().containsKey(file))) {
                message(file);
            }
        }
        System.exit(0);
    }

    /** Reverts the file FILENAME to its state in the head commit. */
    private void checkoutFile(String fileName) {
        Blob foundFile = head().getFile(fileName);
        if (foundFile == null) {
            message("File does not exist in that commit.");
            System.exit(0);
        }
        writeContents(new File(foundFile.name()), foundFile.content());
    }

    /** Reverts the file FILENAME to its state in COMMIT. */
    private void checkoutFile(String commit, String fileName) {
        Commit getFrom = findCommit(commit);
        Blob foundFile = getFrom.getFile(fileName);
        if (foundFile == null) {
            message("File does not exist in that commit.");
            System.exit(0);
        }
        writeContents(new File(foundFile.name()), foundFile.content());
    }

    /** Reverts the file FILENAME to its state in GETFROM. */
    private void checkoutFile(Commit getFrom, String fileName) {
        getFrom.update();
        Blob foundFile = getFrom.getFile(fileName);
        if (foundFile == null) {
            message("File does not exist in that commit.");
            System.exit(0);
        }
        writeContents(new File(foundFile.name()), foundFile.content());
    }

    /** Converts the working directory to its state in BRANCH. */
    private void checkoutBranch(String branch) {
        if (branch.equals(_branch)) {
            message("No need to checkout the current branch.");
            System.exit(0);
        }

        String branchHead = findBranch(branch);
        checkoutCommit(readCommit(new File(_commitsPath + "/" + branchHead)));

        _branch = branch;

    }

    /** Converts the working directory to its state in COMMIT. */
    private void checkoutCommit(Commit commit) {
        HashMap<String, Blob> workingFiles =
                getUnorderedFiles(workingDirectory);

        for (String fileName : workingFiles.keySet()) {
            if (commit.names().containsKey(fileName)) {
                if (!workingFiles.get(fileName).equals(
                        commit.names().get(fileName))) {
                    message("There is an untracked file in the way;"
                            + " delete it or add it first.");
                    System.exit(0);
                }
            }
        }

        for (String file : _head.names().keySet()) {
            if (!commit.names().containsKey(file)
                    || !commit.getFile(file).equals(_head.getFile(file))) {
                new File(workingDirectory + "/" + file).delete();
            }
        }

        _head = commit.update();

        for (String fileName : _head.names().keySet()) {
            File location = new File(workingDirectory + "/" + fileName);
            writeContents(location, _head.names().get(fileName).content());
        }

        removeStagedFiles();
        removeUntrackedFiles();

    }

    /** Creates a new branch named BRANCH with
     *  the head pointer at the current commit. */
    private void branch(String branch) {
        if (_branches.containsKey(branch)) {
            message("A branch with that name already exists.");
            System.exit(0);
        }
        _branches.put(branch, _head.id());
    }

    /** Removes branch BRANCH, unless the user is on the specified branch. */
    private void removeBranch(String branch) {
        if (!_branches.containsKey(branch)) {
            message("A branch with that name does not exist.");
            System.exit(0);
        } else if (_branch.equals(branch)) {
            message("Cannot remove the current branch");
            System.exit(0);
        }
        _branches.remove(branch);
    }

    /** Check out and point this branch's pointer to COMMIT, removing files
     *  not present in that commit. */
    private void reset(String commit) {
        Commit replace = findCommit(commit);
        checkoutCommit(replace);
        _branches.put(branch(), replace.id());
    }

    /** Create the commit resulting from merging branch BRANCH with the
     *  head commit. If ALLOWSAMEBRANCH, allow merges between a branch
     *  and itself (fast-forwarding). */
    private void merge(String branch, boolean allowSameBranch) {
        Commit branchHead = readCommit(
                join(_commitsPath, "/", findBranch(branch)));
        Commit ancestor = latestCommonAncestor(branchHead);
        mergeEdgeCases(branch, ancestor, branchHead, allowSameBranch);

        HashMap<String, Blob> otherCommitNames = branchHead.update().names();
        HashMap<String, Blob> ancestorNames = ancestor.update().names();
        for (String originalFile : ancestorNames.keySet()) {
            if (otherCommitNames.containsKey(originalFile)
                    && !otherCommitNames.get(originalFile)
                    .equals(ancestorNames.get(originalFile))) {
                if (head().names().containsKey(originalFile)
                        && head().names().get(originalFile)
                        .equals(ancestorNames.get(originalFile))) {
                    checkoutFile(branchHead, originalFile);
                    add(originalFile);
                }
            }
            if ((otherCommitNames.containsKey(originalFile)
                    && head().names().containsKey(originalFile)
                    && otherCommitNames.get(originalFile).equals(
                            head().names().get(originalFile)))
                    || (otherCommitNames.get(originalFile) == null
                    && head().names().get(originalFile) == null)) {
                break;
            }
            if (head().names().containsKey(originalFile)
                    && head().names().get(originalFile)
                    .equals(ancestorNames.get(originalFile))) {
                if (!otherCommitNames.containsKey(originalFile)) {
                    rm(originalFile);
                }
            }
        }
        boolean conflict = false;
        for (String fileName : otherCommitNames.keySet()) {
            if (!ancestorNames.containsKey(fileName)
                    && !head().names().containsKey(fileName)) {
                checkoutFile(branchHead.id(), fileName);
                add(fileName);
            }
            if (head().names().containsKey(fileName)) {
                Blob headVersion = head().names().get(fileName);
                Blob otherVersion = otherCommitNames.get(fileName);
                if (!headVersion.equals(otherVersion)) {
                    writeContents(join(fileName),
                            "<<<<<<< HEAD\n", headVersion.content(),
                            "=======\n", otherVersion.content(), "\n>>>>>>>");
                    add(fileName);
                    conflict = true;
                }
            }
        }
        String commitMessage = "Merged " + _branch + " into " + branch + ".";
        mergeCommit(head(), branchHead, commitMessage);
        if (conflict) {
            message("Encountered a merge conflict.");
        }
    }

    /** Exit the program if the input to merge(...) is such that BRANCH
     *  is being merged with itself or the latest common ANCESTOR is the
     *  BRANCHHEAD of the branch to be merged. If ALLOWSAMEBRANCH, ignore
     *  merges between a branch and itself (fast-forwarding).*/
    private void mergeEdgeCases(String branch,
                                Commit ancestor, Commit branchHead,
                                boolean allowSameBranch) {
        if (branch.equals(branch()) && !allowSameBranch) {
            message("Cannot merge a branch with itself.");
            System.exit(0);
        } else if (ancestor == branchHead) {
            message("Given branch is an ancestor of the current branch.");
            System.exit(0);
        } else if (ancestor == head()) {
            _branches.put(branch(), branchHead.id());
            message("Current branch fast-forwarded.");
            System.exit(0);
        }
    }

    /** Add a new remote named REMOTE to this gitlet repository. The
     *  remote points to DIRECTORY, which must end in .gitlet. */
    private void addRemote(String remote, String directory) {
        File remoteSave = new File(_remotesPath + File.separator + remote);

        if (_remotes.contains(remote)) {
            message("A remote with that name already exists.");
            System.exit(0);
        }

        writeContents(remoteSave, directory);
        _remotes.add(remote);
    }

    /** Remove the remote named REMOTE. */
    private void rmRemote(String remote) {
        if (!_remotes.contains(remote)) {
            message("A remote with that name does not exist.");
            System.exit(0);
        } else {
            File remoteSave = new File(_remotesPath + File.separator + remote);
            remoteSave.delete();
            _remotes.remove(remote);
        }
    }

    /** Update REMOTE with all commits up to the head of this BRANCH. */
    private void push(String remote, String branch) {
        checkRemote(remote);
        File remoteSave = new File(_remotesPath + File.separator + remote);
        if (!remoteSave.exists()) {
            message("Remote directory not found.");
            System.exit(0);
        }
        String directory = readContentsAsString(remoteSave);
        File gitletMain = new File(directory + File.separator + "Main");
        Main otherGitlet = readObject(gitletMain, Main.class);
        otherGitlet.getGitlet(new File(directory).getParent());
        otherGitlet.readGitlet();
        HashSet<String> allAncestors = ancestryS(head());
        if (otherGitlet.branches().containsKey(branch)) {
            String lastCommit = otherGitlet.findBranch(branch);
            File readDir = new File(directory + File.separator
                    + "commits" + File.separator + lastCommit);
            Commit otherHead = readCommit(readDir);
            HashSet<String> otherAncestors = otherGitlet.ancestryS(otherHead);
            if (!allAncestors.contains(lastCommit)) {
                message("Please pull down remote changes before pushing.");
                System.exit(0);
            }
            for (String commitID : allAncestors) {
                if (!otherAncestors.contains(commitID)) {
                    readDir = new File(_commitsPath
                            + File.separator + commitID);
                    File writeDir = new File(directory + File.separator
                            + "commits" + File.separator + commitID);
                    Commit toWrite = readObject(readDir, Commit.class).update();
                    for (Blob file : toWrite.getFiles()) {
                        File fileWriteDir = new File(directory + File.separator
                                + "files" + File.separator + file.id());
                        writeObject(fileWriteDir, file);
                    }
                    writeObject(writeDir, toWrite);
                }
            }
        } else {
            HashSet<String> toAdd = ancestryS(head());
            for (String commitID : toAdd) {
                File readDir = new File(_commitsPath
                        + File.separator + commitID);
                File writeDir = new File(directory + File.separator
                        + "commits" + File.separator + commitID);
                Commit toWrite = readObject(readDir, Commit.class).update();

                for (Blob file : toWrite.getFiles()) {
                    File fileWriteDir = new File(directory + File.separator
                            + "files" + File.separator + file.id());
                    writeObject(fileWriteDir, file);
                }
                writeObject(writeDir, toWrite);
            }
        }
        otherGitlet.branches().put(branch, head().id());
        otherGitlet.reset(head().id());
        writeObject(gitletMain, otherGitlet);
    }

    /** Get all commits on branch BRANCH which are not present in this
     *  repository from REMOTE. */
    private void fetch(String remote, String branch) {
        checkRemote(remote);
        File remoteSave = new File(_remotesPath + File.separator + remote);
        if (!remoteSave.exists()) {
            message("Remote directory not found.");
            System.exit(0);
        }
        String directory = readContentsAsString(remoteSave);
        File gitletMain = new File(directory + File.separator + "Main");
        Main otherGitlet = readObject(gitletMain, Main.class);
        otherGitlet.getGitlet(new File(directory).getParent());
        String lastCommit = otherGitlet.branches().getOrDefault(branch, null);
        if (lastCommit == null) {
            error("That remote does not have that branch.");
        }
        HashSet<String> otherAncestors =
                otherGitlet.ancestryFetch(otherGitlet.findCommit(lastCommit));
        if (branches().containsKey(branch)) {
            String ourLastCommit = findBranch(branch);
            File readDir = new File(_commitsPath + SEPARATOR + ourLastCommit);
            Commit ourHead = readCommit(readDir);
            HashSet<String> ourAncestors = ancestryS(ourHead);
            if (ourAncestors.contains(lastCommit)) {
                System.exit(0);
            }
            for (String commitID : otherAncestors) {
                if (!ourAncestors.contains(commitID)) {
                    readDir = new File(directory + File.separator
                            + "commits" + File.separator + commitID);
                    File writeDir = new File(_commitsPath
                            + File.separator + commitID);
                    Commit toWrite = readObject(readDir, Commit.class)
                            .update(otherGitlet);
                    for (Blob file : toWrite.getFiles()) {
                        File fileWriteDir = new File(_filesPath
                                + File.separator + file.id());
                        writeObject(fileWriteDir, file);
                    }
                    writeObject(writeDir, toWrite);
                }
            }
        } else {
            HashSet<String> toAdd = otherAncestors;
            for (String commitID : toAdd) {
                File readDir = new File(directory + File.separator
                        + "commits" + File.separator + commitID);
                File writeDir = new File(_commitsPath
                        + File.separator + commitID);
                Commit toWrite = readObject(readDir, Commit.class)
                        .update(otherGitlet);
                for (Blob file : toWrite.getFiles()) {
                    File fileWriteDir = new File(_gitletPath + File.separator
                            + "files" + File.separator + file.id());
                    writeObject(fileWriteDir, file);
                }
                writeObject(writeDir, toWrite);
            }
        }
        branches().put(branch, lastCommit);
    }

    /** Fetch branch BRANCH from REMOTE and merge it into the current head. */
    private void pull(String remote, String branch) {
        fetch(remote, branch);
        merge(branch, true);
    }

    /** Return all ancestors of COMMIT, ending in the initial commit. */
    private HashSet<Commit> ancestry(Commit commit) {
        HashSet<Commit> ancestors = new HashSet<>();
        while (commit != null) {
            ancestors.add(commit);
            if (commit.isMerge()) {
                ancestors.addAll(ancestry(commit.mergeParent()));
            }
            commit = commit.parent();
        }
        return ancestors;
    }

    /** Return all ancestors of COMMIT, ending in the initial commit. */
    private HashSet<String> ancestryS(Commit commit) {
        HashSet<String> ancestors = new HashSet<>();
        while (commit != null) {
            ancestors.add(commit.id());
            if (commit.isMerge()) {
                ancestors.addAll(ancestryS(commit.mergeParent()));
            }
            commit = commit.parent();
        }
        return ancestors;
    }

    /** Return all ancestors of COMMIT, ending in the initial commit.
     *  Compatibility with testing by accommodating for different
     *  working directories created by copying a Gitlet repository. */
    private HashSet<String> ancestryFetch(Commit commit) {
        HashSet<String> ancestors = new HashSet<>();
        while (commit != null) {
            ancestors.add(commit.id());
            if (commit.isMerge()) {
                ancestors.addAll(ancestryS(commit.mergeParent()));
            }
            Commit parent = null;
            if (commit.parent() != null) {
                parent = commit.parent().update(this);
            }
            commit = parent;
        }
        return ancestors;
    }

    /** Return the head commit's latest common ancestor with COMMIT. */
    private Commit latestCommonAncestor(Commit commit) {
        HashSet<String> ancestry = ancestryS(head());
        return commonAncestor(commit, ancestry, 0).commit();
    }

    /** Internal structure for searching through ancestors. */
    private class CommitDistance {
        /** Construct a CommitDistance, which specifies
         *  a COMMIT and its DISTANCE from the head commit. */
        CommitDistance(Commit commit, int distance) {
            _commit = commit;
            _distance = distance;
        }

        /** Return the commit belonging to me. */
        public Commit commit() {
            return _commit;
        }

        /** Return my distance. */
        public int distance() {
            return _distance;
        }

        /** My commit. */
        private Commit _commit;
        /** My distance. */
        private int _distance;
    }

    /** Searches Commit COMMIT's parents for an ancestor in ANCESTRY.
     *  Returns the Commit that is the closest number of jumps from
     *  COMMIT, starting the distance measurement from DISTANCE. */
    private CommitDistance commonAncestor(Commit commit,
                                          HashSet<String> ancestry,
                                          int distance) {
        while (commit != null) {
            if (ancestry.contains(commit.id())) {
                return new CommitDistance(commit, distance);
            } else if (commit.isMerge()) {
                CommitDistance mainParent =
                        commonAncestor(commit.parent(), ancestry, distance);
                CommitDistance mergeParent = commonAncestor(
                        commit.mergeParent(), ancestry, distance);
                if (mainParent.distance() < mergeParent.distance()) {
                    return mainParent;
                } else {
                    return mergeParent;
                }
            }
            commit = commit.parent();
            distance++;
        }
        return null;
    }


    /** Store this Main instance in the .gitlet directory. */
    private void storeGitlet() {
        File location = new File(_gitletPath + "/main");
        writeObject(location, this);
    }

    /** Load the last saved Main class for this repository and return
     * the commit at the head of the active branch. */
    private Commit readGitlet() {
        File location = new File(_gitletPath + "/main");
        Main reference = readObject(location, Main.class);
        _branches = reference._branches;
        _branch = reference.branch();
        _remotes = reference._remotes;
        _stagedFiles = reference._stagedFiles;

        File currentCommit = new File(_gitletPath
                + "/commits/" + _branches.get(_branch));
        _head = readObject(currentCommit, Commit.class).update();

        return _head;
    }

    /** Return whether the subdirectory workingDirectory/.gitlet exists
     *  and assign _gitletPath to that directory if it does. */
    private boolean getGitlet() {
        workingDirectory = new File(".");
        File gitletPath = new File(workingDirectory, ".gitlet")
                .getAbsoluteFile();
        if (!gitletPath.exists()) {
            return false;
        } else {
            if (_gitletPath == null) {
                _gitletPath = gitletPath;
                readGitlet();
                _filesPath = new File(_gitletPath + "/files/");
                _commitsPath = new File(_gitletPath + "/commits/");
                _stagingPath = new File(_gitletPath + "/staging/");
                _untrackedPath = new File(_gitletPath + "/untracked/");
                _remotesPath = new File(_gitletPath + "/remotes/");
            }

            return true;
        }
    }

    /** Return whether the subdirectory DIRECTORY/.gitlet exists
     *  and assign _gitletPath to that directory if it does. */
    private boolean getGitlet(String directory) {
        workingDirectory = new File(directory);
        File gitletPath = new File(directory, ".gitlet").getAbsoluteFile();
        if (!gitletPath.exists()) {
            return false;
        } else {
            if (_gitletPath == null) {
                _gitletPath = gitletPath;
                _filesPath = new File(_gitletPath + "/files/");
                _commitsPath = new File(_gitletPath + "/commits/");
                _stagingPath = new File(_gitletPath + "/staging/");
                _untrackedPath = new File(_gitletPath + "/untracked/");
                _remotesPath = new File(_gitletPath + "/remotes/");
            }

            return true;
        }
    }

    /** Ensure that arguments ARGS have length EXPECTED. */
    private void expectedArgs(int expected, String[] args) {
        if (args.length != expected) {
            message("Incorrect operands.");
            System.exit(0);
        }
    }

    /** Given an abbreviation String ABBREV, return the first found String
     *  that begins with ABBREV from MATCHES. */
    private String matchAbbreviation(String abbrev, List<String> matches) {
        int abbreviationLength = abbrev.length();
        for (String fullText : matches) {
            if (abbrev.equals(fullText.substring(0, abbreviationLength))) {
                return fullText;
            }
        }
        return null;
    }

    /** Find the commit with the abbreviated prefix COMMIT and return it.
     *  Exit the program if no commit is found. */
    private Commit findCommit(String commit) {
        commit = matchAbbreviation(commit, plainFilenamesIn(_commitsPath));
        if (commit == null) {
            message("No commit with that id exists.");
            System.exit(0);
        }
        return readCommit(new File(_commitsPath + File.separator + commit));
    }

    /** Find the head pointer of BRANCH and return it.
     *  Unlike findCommit, the provided String must match exactly.
     *  Abbreviations are not permitted. */
    private String findBranch(String branch) {
        String headPointer = _branches.getOrDefault(branch, null);
        if (headPointer == null) {
            error("No such branch exists.");
        }
        return headPointer;
    }

    /** Exit the program if no remote named REMOTE exists. */
    private void checkRemote(String remote) {
        if (!_remotes.contains(remote)) {
            message("No remote with that name was found.");
            System.exit(0);
        }
    }

    /** Return the file named FILENAME in the working directory, or
     *  exit if it does not exist. */
    private File getFile(String fileName) {
        File file = new File(workingDirectory + File.separator + fileName);
        if (!file.isFile()) {
            message("File does not exist.");
            System.exit(0);
        }
        return file;
    }

    /** Returns all files in DIRECTORY unsorted. */
    private HashMap<String, Blob> getUnorderedFiles(File directory) {
        List<String> fileSet = plainFilenamesIn(directory);
        HashMap<String, Blob> allUnordered = new HashMap<>();
        for (String file : fileSet) {
            File pathToFile = new File(directory + File.separator + file);
            try {
                allUnordered.put(file, readBlob(pathToFile));
            } catch (IllegalArgumentException excp) {
                allUnordered.put(file, new Blob(new File(file)));
            }

        }
        return allUnordered;
    }

    /** Returns all files in DIRECTORY sorted by their file name in the
     *  directory, in lexicographic order. */
    private TreeMap<String, Blob> getOrderedFiles(File directory) {
        List<String> fileSet = plainFilenamesIn(directory);
        TreeMap<String, Blob> allOrdered = new TreeMap<>();
        for (String file : fileSet) {
            File pathToFile = new File(directory + File.separator + file);
            try {
                allOrdered.put(file, readBlob(pathToFile));
            } catch (IllegalArgumentException excp) {
                allOrdered.put(file, new Blob(new File(file)));
            }

        }
        return allOrdered;
    }

    /** Returns all files in DIRECTORY sorted by their true file name
     * (the property stored in their Blob object), in lexicographic order. */
    private TreeMap<String, Blob> getOrderedFilesByName(File directory) {
        List<String> fileSet = plainFilenamesIn(directory);
        TreeMap<String, Blob> allOrdered = new TreeMap<>();
        for (String file : fileSet) {
            File pathToFile = new File(directory + File.separator + file);
            try {
                Blob blob = readBlob(pathToFile);
                allOrdered.put(blob.name(), blob);
            } catch (IllegalArgumentException excp) {
                Blob blob = new Blob(new File(file));
                allOrdered.put(blob.name(), blob);
            }

        }
        return allOrdered;
    }

    /** Returns all files in DIRECTORY sorted by their true file name. */
    private HashMap<String, Blob> getUnorderedFilesByName(File directory) {
        List<String> fileSet = plainFilenamesIn(directory);
        HashMap<String, Blob> allUnordered = new HashMap<>();
        for (String file : fileSet) {
            File pathToFile = new File(directory + File.separator + file);
            try {
                Blob blob = readBlob(pathToFile);
                allUnordered.put(blob.name(), blob);
            } catch (IllegalArgumentException excp) {
                Blob blob = new Blob(new File(file));
                allUnordered.put(blob.name(), blob);
            }

        }
        return allUnordered;
    }

    /** Return the Blob stored in FILE. */
    private Blob readBlob(File file) {
        return readObject(file, Blob.class);
    }

    /** Return the commit stored in FILE. */
    private Commit readCommit(File file) {
        return readObject(file, Commit.class).update(this);
    }

    /** Remove all files in the staging path. */
    private void removeStagedFiles() {
        for (String fileName : plainFilenamesIn(_stagingPath)) {
            new File(_stagingPath + File.separator + fileName).delete();
        }
    }
    /** Remove all files that have been marked to be untracked. */
    private void removeUntrackedFiles() {
        for (String fileName : plainFilenamesIn(_untrackedPath)) {
            new File(_untrackedPath + File.separator + fileName).delete();
        }
    }

    /** Return all available branches in alphabetical order. */
    public TreeMap<String, String> branches() {
        return _branches;
    }

    /** Return the current branch. */
    public String branch() {
        return _branch;
    }

    /** Return the commit at the head pointer. */
    public Commit head() {
        return _head;
    }

    /* Strings for printing and comparison: */

    /** Potential commands. */
    private static final String[] COMMANDS = {"init", "add", "commit", "rm",
        "log", "global-log", "find", "status", "checkout", "branch",
        "rm-branch", "reset", "merge", "add-remote", "rm-remote", "push",
        "fetch", "pull"};

    /** String to print if no arguments are provided. */
    private static final String NO_ARGS = "Please enter a command.";

    /** File separator. */
    private static final String SEPARATOR = File.separator;

    /* File location information: */

    /** Return the working directory. */
    public File getWorkingDirectory() {
        return workingDirectory;
    }

    /** Working directory. */
    private transient File workingDirectory = new File(".").getAbsoluteFile();

    /** Gitlet directory. */
    private transient File _gitletPath;

    /** Return the path to this repository's commits. */
    public File getFilePath() {
        return _filesPath;
    }

    /** File storage subdirectory. */
    private transient File _filesPath;

    /** Return the path to this repository's commits. */
    public File getCommitPath() {
        return _commitsPath;
    }

    /** Commit storage subdirectory. */
    private transient File _commitsPath;

    /** Staging subdirectory. */
    private transient File _stagingPath;

    /** Untracked files subdirectory. */
    private transient File _untrackedPath;

    /** Remote storage subdirectory. */
    private transient File _remotesPath;

    /* Non-fixed properties */

    /** Head pointer. */
    private transient Commit _head;

    /** Command passed in to call to gitlet.Main. */
    private String _command;

    /** All currently staged files' names and corresponding ID. */
    private HashMap<String, String> _stagedFiles;

    /** Branch heads. */
    private TreeMap<String, String> _branches;

    /** Current branch of this repository. */
    private String _branch;

    /** The set of all available remote names. */
    private HashSet<String> _remotes;

}
