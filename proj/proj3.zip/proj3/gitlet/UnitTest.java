package gitlet;

import ucb.junit.textui;
import org.junit.Test;

import java.io.File;

import static org.junit.Assert.*;

/** The suite of all JUnit tests for the gitlet package.
 *  @author
 */
public class UnitTest {

    /** Run the JUnit tests in the loa package. Add xxxTest.class entries to
     *  the arguments of runClasses to run other JUnit tests. */
    public static void main(String[] ignored) {
        textui.runClasses(UnitTest.class);
    }

    /** Ensure commit initialization results in the default commit. */
    @Test
    public void commitInitTest() {
        Commit initial = new Commit();
        assertEquals("initial commit", initial.message());
    }

    /** Ensure that serialization returns the same object (a sanity check). */
    @Test
    public void serializeReadTest() {
        Commit initial = new Commit();
        File temp = new File("nickvitalievichkisel");
        Utils.writeObject(temp, initial);

        Commit read = Utils.readObject(temp, Commit.class);
        assertEquals("initial commit", read.message());
    }

    @Test
    public void makeSomeCommitsBaby() {
        Main original = new Main(new String[] {"init"});
    }


}


