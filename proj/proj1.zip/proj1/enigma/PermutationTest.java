package enigma;

import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.Timeout;
import static org.junit.Assert.*;

import static enigma.TestUtils.*;

/** The suite of all JUnit tests for the Permutation class.
 *  @author Nick Kisel
 */
public class PermutationTest {

    /** Testing time limit. */
    @Rule
    public Timeout globalTimeout = Timeout.seconds(5);

    /* ***** TESTING UTILITIES ***** */

    private Permutation perm;
    private String alpha = UPPER_STRING;

    /** Check that perm has an alphabet whose size is that of
     *  FROMALPHA and TOALPHA and that maps each character of
     *  FROMALPHA to the corresponding character of FROMALPHA, and
     *  vice-versa. TESTID is used in error messages. */
    private void checkPerm(String testId,
                           String fromAlpha, String toAlpha) {
        int N = fromAlpha.length();
        assertEquals(testId + " (wrong length)", N, perm.size());
        for (int i = 0; i < N; i += 1) {
            char c = fromAlpha.charAt(i), e = toAlpha.charAt(i);
            assertEquals(msg(testId, "wrong translation of '%c'", c),
                         e, perm.permute(c));
            assertEquals(msg(testId, "wrong inverse of '%c'", e),
                         c, perm.invert(e));
            int ci = alpha.indexOf(c), ei = alpha.indexOf(e);
            assertEquals(msg(testId, "wrong translation of %d", ci),
                         ei, perm.permute(ci));
            assertEquals(msg(testId, "wrong inverse of %d", ei),
                         ci, perm.invert(ei));
        }
    }

    /* ***** TESTS ***** */
    @Test
    public void selfTest1() {
        perm = new Permutation("", UPPER);
        char upperA = 'A';
        int intValueA = upperA;
        assertEquals(upperA,
                perm.alphabet().toChar(perm.alphabet().toInt(upperA)));
    }



    @Test
    public void checkIdTransform() {
        perm = new Permutation("", UPPER);
        checkPerm("identity", UPPER_STRING, UPPER_STRING);
    }

    @Test
    public void alphabetPermutation() {
        perm = new Permutation("(AB)", UPPER);
        checkPerm("AtoB", "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                "BACDEFGHIJKLMNOPQRSTUVWXYZ");
        perm = new Permutation("(ADGJMPSV)", UPPER);
        checkPerm("almostEveryThird", UPPER_STRING,
                "DBCGEFJHIMKLPNOSQRVTUAWXYZ");
        perm = new Permutation("(ABCDEFGHIJKLMNOPQRSTUVWXYZ)", UPPER);
        checkPerm("shiftAll", UPPER_STRING, "BCDEFGHIJKLMNOPQRSTUVWXYZA");
        perm = new Permutation("(ABCDEFGHIJKLM) (NOPQRSTUVWXYZ)", UPPER);
        checkPerm("twoGroups", UPPER_STRING, "BCDEFGHIJKLMAOPQRSTUVWXYZN");
        perm = new Permutation("(NO) (AB) (YZ) (GH)", UPPER);
        checkPerm("clusters", UPPER_STRING, "BACDEFHGIJKLMONPQRSTUVWXZY");
    }

    @Test
    public void alternatePermutation() {

        Alphabet basic = new Alphabet("M");

        perm = new Permutation("", basic);
        alpha = "M";
        checkPerm("basecase", alpha, alpha);

        Alphabet homerow = new Alphabet("ASDFGHJKL");

        perm = new Permutation("(AJL) (DF)", homerow);
        alpha = "ASDFGHJKL";
        checkPerm("homerow", "ASDFGHJKL", "JSFDGHLKA");

    }

    @Test
    public void upperLowerTest() {

        Alphabet upperlower = new Alphabet(UPPER_LOWER);

        perm = new Permutation("", upperlower);
        alpha = UPPER_LOWER;
        checkPerm("upperLowerIdentity", alpha, alpha);

        perm = new Permutation("(aA) (bB) (cC) (dD) (eE) (fF) (gG) "
                + "(hH) (iI) (jJ) (kK) (lL) (mM) (nN) (oO) (pP) (qQ) (rR)"
                + "(sS) (tT) (uU) (vV) (wW) (xX) (yY) (zZ)", upperlower);
        checkPerm("upperLowerPairs", alpha,
                "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
        assertEquals(true, perm.derangement());

    }



    @Test (expected = EnigmaException.class)
    public void letterNotFoundException() {

        Alphabet basic = new Alphabet("EFGHIJK");

        perm = new Permutation("(KQ)", basic);
        alpha = "EFGHIJK";
        checkPerm("letterNotFoundException", alpha, alpha);

    }

    @Test (expected = EnigmaException.class)
    public void duplicateLetterException() {

        Alphabet upperlower = new Alphabet(UPPER_LOWER);

        perm = new Permutation("(thequickbrownfoxjumpsoverthelazydog) "
                + "(THEQUICKBROWNFOXJUMPSOVERTHELAZYDOG)", upperlower);
        alpha = UPPER_LOWER;
        checkPerm("duplicateLetterException", alpha, alpha);

    }

    @Test (expected = EnigmaException.class)
    public void duplicateLetterEdgeCase() {

        Alphabet upperlower = new Alphabet(UPPER_LOWER);

        perm = new Permutation("(aba) ", upperlower);
        alpha = UPPER_LOWER;
        checkPerm("duplicateLetterEdgeCase", alpha, alpha);

    }

    @Test
    public void checkDerangement() {

        Alphabet upperlower = new Alphabet(UPPER_LOWER);

        perm = new Permutation("(AY) (BR) (CU) (DH) (EQ) (FS)"
                + " (GL) (IP) (JX) (KN) (MO) (TZ) (VW)", upperlower);
        assertEquals(false, perm.derangement());

        perm = new Permutation("(AY) (BR) (CU) (DH) (EQ) (FS)"
                + " (GL) (IP) (JX) (KN) (MO) (TZ) (VW)", UPPER);
        assertEquals(true, perm.derangement());
    }

}
