package enigma;

import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.Timeout;
import static org.junit.Assert.*;

import java.util.HashMap;

import static enigma.TestUtils.*;

/** The suite of all JUnit tests for the Permutation class.
 *  @author Nick Kisel
 */
public class MovingRotorTest {

    /** Testing time limit. */
    @Rule
    public Timeout globalTimeout = Timeout.seconds(5);

    /* ***** TESTING UTILITIES ***** */

    private Rotor rotor;
    private String alpha = UPPER_STRING;

    /** Check that rotor has an alphabet whose size is that of
     *  FROMALPHA and TOALPHA and that maps each character of
     *  FROMALPHA to the corresponding character of FROMALPHA, and
     *  vice-versa. TESTID is used in error messages. */
    private void checkRotor(String testId,
                            String fromAlpha, String toAlpha) {
        int N = fromAlpha.length();
        assertEquals(testId + " (wrong length)", N, rotor.size());
        for (int i = 0; i < N; i += 1) {
            char c = fromAlpha.charAt(i), e = toAlpha.charAt(i);
            int ci = alpha.indexOf(c), ei = alpha.indexOf(e);
            assertEquals(msg(testId, "wrong translation of %d (%c)", ci, c),
                         ei, rotor.convertForward(ci));
            assertEquals(msg(testId, "wrong inverse of %d (%c)", ei, e),
                         ci, rotor.convertBackward(ei));
        }
    }

    /** Set the rotor to the one with given NAME and permutation as
     *  specified by the NAME entry in ROTORS, with given NOTCHES. */
    private void setRotor(String name, HashMap<String, String> rotors,
                          String notches) {
        rotor = new MovingRotor(name, new Permutation(rotors.get(name), UPPER),
                                notches);
    }

    /* ***** TESTS ***** */

    @Test
    public void checkRotorAtA() {
        setRotor("I", NAVALA, "");
        checkRotor("Rotor I (A)", UPPER_STRING, NAVALA_MAP.get("I"));
    }

    @Test
    public void checkRotorAdvance() {
        setRotor("I", NAVALA, "");
        rotor.advance();
        checkRotor("Rotor I advanced", UPPER_STRING, NAVALB_MAP.get("I"));
    }

    @Test
    public void checkRotorSet() {
        setRotor("I", NAVALA, "");
        rotor.set(25);
        checkRotor("Rotor I set", UPPER_STRING, NAVALZ_MAP.get("I"));
    }

    @Test
    public void checkSetChar() {
        setRotor("IV", NAVALB, "E");
        rotor.set(3);
        Rotor setInt = rotor;

        setRotor("IV", NAVALB, "E");
        rotor.set('D');

        assertEquals(rotor.setting(), setInt.setting());
    }

    @Test (expected = EnigmaException.class)
    public void checkIllegalChar() {
        setRotor("II", NAVALA, "E");
        rotor.set('b');
        assertEquals(0, rotor.setting());
    }

    @Test
    public void checkFullRotation() {
        setRotor("VII", NAVALZ, "");
        for (int i = 0; i < 26; i++) {
            rotor.advance();
        }
        checkRotor("Rotor VI fully rotated",
                UPPER_STRING, NAVALZ_MAP.get("VII"));

        rotor.advance();
        checkRotor("Rotor VI resets setting to A",
                UPPER_STRING, NAVALA_MAP.get("VII"));
    }

    @Test
    public void checkAtNotch() {
        setRotor("V", NAVALA, "A");
        rotor.set(25);
        assertEquals(false, rotor.atNotch());

        rotor.advance();
        assertEquals(true, rotor.atNotch());

        rotor.advance();
        assertEquals(false, rotor.atNotch());
    }

    @Test
    public void checkParametersSet() {
        String allNotches = "GHIJKLMNOPX";

        setRotor("IV", NAVALA, allNotches);
        for (int i = 0; i < allNotches.length(); i++) {
            assertEquals(true, rotor._notches.contains(
                    rotor.alphabet().toInt(allNotches.charAt(i))));
        }

        assertEquals(true, rotor.rotates());
        assertEquals(false, rotor.atNotch());
    }

    @Test
    public void checkRingstellung() {
        setRotor("VIII", NAVALA, "BC");
        rotor.setRingstellung(15);
        rotor.set(0 - 15);
        assertEquals(false, rotor.atNotch());
        rotor.advance();
        assertEquals(true, rotor.atNotch());
        rotor.advance();
        assertEquals(true, rotor.atNotch());
        for (int i = 0; i < 24; i++) {
            rotor.advance();
            assertEquals(false, rotor.atNotch());
        }
        rotor.advance();
        assertEquals(true, rotor.atNotch());
    }

    @Test
    public void check() {

    }

}
