package enigma;

import java.util.ArrayList;
import static enigma.EnigmaException.*;

/** Superclass that represents a rotor in the enigma machine.
 *  @author Nick Kisel
 */
class Rotor {

    /** A rotor named NAME whose permutation is given by PERM. */
    Rotor(String name, Permutation perm) {
        _name = name;
        _permutation = perm;
        _setting = 0;
        _reflector = false;
        _rotates = false;
        _notches = new ArrayList<>();
        _ringstellung = 0;
    }

    /** Return my name. */
    String name() {
        return _name;
    }

    /** Return my alphabet. */
    Alphabet alphabet() {
        return _permutation.alphabet();
    }

    /** Return my permutation. */
    Permutation permutation() {
        return _permutation;
    }

    /** Return the size of my alphabet. */
    int size() {
        return _permutation.size();
    }

    /** Return true iff I have a ratchet and can move. */
    boolean rotates() {
        return _rotates;
    }

    /** Return true iff I reflect. */
    boolean reflecting() {
        return _reflector;
    }

    /** Return my current setting. */
    int setting() {
        return _setting;
    }

    /** Set setting() to POSN.  */
    void set(int posn) {
        _setting = permutation().wrap(posn);
    }

    /** Set setting() to character CPOSN. */
    void set(char cposn) {
        if (alphabet().contains(cposn)) {
            _setting = alphabet().toInt(cposn);
        } else {
            throw error("Letter %s not found in alphabet.", cposn);
        }
    }

    /** Return the conversion of P (an integer in the range 0..size()-1)
     *  according to my permutation. */
    int convertForward(int p) {
        return permutation().wrap(
                permutation().permute(p + setting()) - setting());
    }

    /** Return the conversion of E (an integer in the range 0..size()-1)
     *  according to the inverse of my permutation. */
    int convertBackward(int e) {
        return permutation().wrap(
                permutation().invert(e + setting()) - setting());
    }

    /** Returns true iff I am positioned to allow the rotor to my left
     *  to advance. */
    boolean atNotch() {
        return _notches.contains(_permutation.wrap(setting() + _ringstellung));
    }

    /** Advance me one position, if possible. By default, does nothing. */
    void advance() {
    }

    /** Set the ringstellung to POSN, shifting translation and moving
     *  notches.  */
    void setRingstellung(int posn) {
        _ringstellung = posn;
    }

    @Override
    public String toString() {
        return "Rotor " + _name;
    }

    /** My name. */
    private final String _name;

    /** The permutation implemented by this rotor in its 0 position. */
    private Permutation _permutation;

    /** This rotor's number of forward rotations from the 'A' position. */
    private int _setting;

    /** Represents whether or not this rotor represents a reflector. */
    protected boolean _reflector;

    /** Represents whether or not this rotor rotates (is a "moving rotor"). */
    protected boolean _rotates;

    /** A list of the settings at which pawls may interact with the
     *  notches in this rotor's alphabet ring, causing further rotation. */
    protected ArrayList<Integer> _notches;

    /** This rotor's ringstellung position. */
    protected int _ringstellung;

}
